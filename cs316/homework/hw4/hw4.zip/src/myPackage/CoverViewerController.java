//// Fig. 13.14: CoverViewerController.java
// Controller for Cover Viewer application
package myPackage;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class CoverViewerController {
   // instance variables for interacting with GUI
   //@FXML private ImageView coverImageView;
   @FXML private ListView<Contact> booksListView;
   @FXML private TextField fNameTextField;
   @FXML private TextField lNameTextField;
   @FXML private TextField phoneNoTextField;
   @FXML private TextField emailTextField; 
   @FXML
   private ImageView contactImageView;
   
   // stores the list of Book Objects
   private final ObservableList<Contact> contacts = 
      FXCollections.observableArrayList();

   // initialize controller
   public void initialize() {
      // populate the ObservableList<Book>
      contacts.add(new Contact(
    		  "Donstar", 
    		  "Farlon", 
    		  "888-910-8888", 
    		  "dFarlon@email.com",
    		  "/assets/hunter.jpg"));
      
      contacts.add(new Contact(
    		  "Jasmin", 
    		  "Thao", 
    		  "999-518-1111", 
    		  "jThao@email.com",
    		  "/assets/mage.jpg"));
      
      contacts.add(new Contact(
    		  "Tswjfwmeng", 
    		  "Vang", 
    		  "555-930-5555", 
    		  "tswjfwmeng@email.com",
    		  "/assets/rogue.jpg"));
     
      booksListView.setItems(contacts); // bind booksListView to books

      // when ListView selection changes, show large cover in ImageView
      booksListView.getSelectionModel().selectedItemProperty().
         addListener(
            new ChangeListener<Contact>() {                                   
               @Override                                                     
               public void changed(ObservableValue<? extends Contact> ov,
                  Contact oldValue, Contact newValue) {                        
            	   fNameTextField.setText(newValue.getFName());
            	   
            	   lNameTextField.setText(newValue.getLName());
            	   
            	   phoneNoTextField.setText(newValue.getPhoneNo());
            	   
            	   emailTextField.setText(newValue.getEmail());
            	   
            	   contactImageView.setImage(
            			   new Image(newValue.getThumbnail()));
            	   
                  /*coverImageView.setImage(
                     new Image(newValue.getLargeImage()));*/
               }
            }
         );                                                                  
   }     
}

/**************************************************************************
 * (C) Copyright 1992-2018 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
