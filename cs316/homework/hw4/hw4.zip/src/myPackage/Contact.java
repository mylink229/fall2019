package myPackage;

public class Contact {
   private String fName; 
   private String lName; 
   private String email; 
   private String phoneNo; 
   private String thumbNail;

   public Contact(
		   String fName, 
		   String lName, 
		   String email, 
		   String phoneNo, 
		   String image) {
      this.fName = fName;
      this.lName = lName;
      this.email = email;
      this.phoneNo = phoneNo;
      this.thumbNail = image;
   }
   
   public void setThumbnail(String image) {
	   this.thumbNail = image;
   }
   
   public String getThumbnail() {
	   String thumbNail = this.thumbNail;
	   return thumbNail;
   }
   
   public String getName() {
	   String name = this.fName + " " + this.lName;
	   return name;
   }
   
   public String getFName() {
	   String name = this.fName;
	   return name;
   }
   
   public String getLName() {
	   String name = this.lName;
	   return name;
   }

   public void setLName(String name) {
	   this.lName = name;
   }
   
   public void setFName(String name) {
	   this.fName = name;
   }
   
   public String getEmail() {
	   String email = this.email;
	   return email;
   }

   public void setEmail(String email) {
	   this.email = email;
   }

   public String getPhoneNo() {
	   String phoneNo = this.phoneNo;
	   return phoneNo;
   }

   public void setPhoneNo(String phoneNo) {
	   this.phoneNo = phoneNo;
   }
   
   @Override
   public String toString() {
	   return getName();
   }
}
